import { createGlobalStyle } from 'styled-components';

export default createGlobalStyle<{ theme: any }>`
  :root {
    --brand-primary: #0284c7;
    --brand-primary-light: #38bdf8;
    --brand-primary-dark: #0369a1;
    --brand-success: #10b981;
    --brand-danger: #ef4444;
    
    --bg-glass-panel: rgba(11, 15, 25, 0.88);
    --bg-glass-card: rgba(17, 24, 39, 0.70);
    --bg-glass-card-hover: rgba(24, 33, 53, 0.85);
    --bg-glass-card-active: rgba(30, 41, 65, 0.95);
    --bg-glass-input: rgba(9, 13, 22, 0.80);

    --border-subtle: rgba(255, 255, 255, 0.07);
    --border-card: rgba(255, 255, 255, 0.10);
    --border-focus: rgba(56, 189, 248, 0.55);

    --text-primary: #f8fafc;
    --text-secondary: #94a3b8;
    --text-muted: #64748b;
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    outline: none;
    -webkit-tap-highlight-color: transparent;
    font-family: ${props => props.theme?.fontFamily ? `'${props.theme.fontFamily}', ` : ''}'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  html, body {
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    user-select: none;
    -webkit-user-select: none;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-rendering: optimizeLegibility;
  }
  
  body {
    background: transparent;
    color: var(--text-primary);
  }


  body.dev-mode {
    background: radial-gradient(circle at 75% 45%, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.95) 70%, #090d16 100%),
      url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1920&q=80') center/cover no-repeat;
  }

  button {
    cursor: pointer;
    border: none;
    background: none;
    font-family: inherit;
    transition: color 0.15s ease, background-color 0.15s ease, border-color 0.15s ease, box-shadow 0.15s ease;
  }

  input, select, textarea {
    font-family: inherit;
  }


  ::-webkit-scrollbar {
    width: 5px;
    height: 5px;
  }

  ::-webkit-scrollbar-track {
    background: transparent;
  }

  ::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 999px;
    transition: background 0.15s ease;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: rgba(56, 189, 248, 0.4);
  }


  @keyframes tooltipFadeIn {
    from {
      opacity: 0;
      transform: translateY(3px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }


  @media (prefers-reduced-motion: reduce) {
    *, ::before, ::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
  }
`;
