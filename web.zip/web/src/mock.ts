import {
  APPEARANCE_INITIAL_STATE,
  SETTINGS_INITIAL_STATE,
} from './components/Appearance/settings';
import { CustomizationConfig } from './components/Appearance/interfaces';

interface Mocks {
  [key: string]: any;
}

export const mocks: Mocks = {};

export default function mock(event: string, value: any): void {
  mocks[event] = value;
}

export const defaultMockLocales = {
  modal: {
    save: {
      title: 'Uiterlijk Opslaan',
      description: 'Weet je zeker dat je jouw huidige uiterlijk en kleding wilt opslaan?',
    },
    exit: {
      title: 'Menu Verlaten',
      description: 'Weet je zeker dat je wilt afsluiten? Niet-opgeslagen wijzigingen gaan verloren.',
    },
    accept: 'Opslaan',
    decline: 'Annuleren',
  },
  ped: {
    title: 'Personage Model',
    model: 'Model',
  },
  headBlend: {
    title: 'Erfelijkheid & Vorm',
    shape: {
      title: 'Vader & Moeder Vorm',
      firstOption: 'Vader Vorm',
      secondOption: 'Moeder Vorm',
      mix: 'Vorm Mix',
    },
    skin: {
      title: 'Vader & Moeder Huid',
      firstOption: 'Vader Huid',
      secondOption: 'Moeder Huid',
      mix: 'Huid Mix',
    },
    race: {
      title: 'Derde Erfelijkheid',
      shape: 'Derde Vorm',
      skin: 'Derde Huid',
      mix: 'Derde Mix',
    },
  },
  faceFeatures: {
    title: 'Gelaatstrekken',
    nose: {
      title: 'Neus',
      width: 'Breedte',
      height: 'Hoogte',
      size: 'Grootte',
      boneHeight: 'Bot Hoogte',
      boneTwist: 'Bot Verdraaiing',
      peakHeight: 'Punt Hoogte',
    },
    eyebrows: {
      title: 'Wenkbrauwen',
      height: 'Hoogte',
      depth: 'Diepte',
    },
    cheeks: {
      title: 'Wangen',
      boneHeight: 'Jukbeen Hoogte',
      boneWidth: 'Jukbeen Breedte',
      width: 'Wang Breedte',
    },
    eyesAndMouth: {
      title: 'Ogen & Mond',
      eyesOpening: 'Oog Opening',
      lipsThickness: 'Lip Dikte',
    },
    jaw: {
      title: 'Kaak',
      width: 'Kaak Breedte',
      size: 'Kaak Lengte',
    },
    chin: {
      title: 'Kin',
      lowering: 'Kin Hoogte',
      length: 'Kin Lengte',
      size: 'Kin Grootte',
      hole: 'Kin Kuiltje',
    },
    neck: {
      title: 'Nek',
      thickness: 'Nek Dikte',
    },
  },
  headOverlays: {
    title: 'Haar & Verzorging',
    hair: {
      title: 'Haar',
      style: 'Kapsel',
      color: 'Kleur',
      highlight: 'Highlight',
      fade: 'Fade / Overloop',
      texture: 'Textuur',
    },
    opacity: 'Dekking',
    style: 'Stijl',
    color: 'Kleur',
    secondColor: 'Tweede Kleur',
    blemishes: 'Huidoneffenheden',
    beard: 'Baard',
    eyebrows: 'Wenkbrauwen',
    ageing: 'Veroudering',
    makeUp: 'Make-up',
    blush: 'Blush',
    complexion: 'Teint',
    sunDamage: 'Zonschade',
    lipstick: 'Lippenstift',
    moleAndFreckles: 'Sproeten & Vlekken',
    chestHair: 'Borsthaar',
    bodyBlemishes: 'Lichaamsoneffenheden',
    eyeColor: 'Oogkleur',
  },
  components: {
    title: 'Kleding & Outfits',
    drawable: 'Kledingstuk',
    texture: 'Variatie / Textuur',
    mask: 'Maskers',
    upperBody: 'Bovenlichaam & Armen',
    lowerBody: 'Broeken',
    bags: 'Tassen & Uitrusting',
    shoes: 'Schoenen',
    scarfAndChains: 'Kettingen & Sjaals',
    shirt: 'T-Shirts & Onderkleding',
    bodyArmor: 'Kogelvrije Vesten',
    decals: 'Badges & Emblemen',
    jackets: 'Jassen & Bovenkleding',
    head: 'Hoofd',
  },
  props: {
    title: 'Accessoires',
    drawable: 'Accessoire',
    texture: 'Variatie / Textuur',
    hats: 'Hoeden & Helmen',
    glasses: 'Brillen',
    ear: 'Oorbellen',
    watches: 'Horloges',
    bracelets: 'Armbanden',
  },
  tattoos: {
    title: 'Tatoeages',
    items: {
      ZONE_TORSO: 'Romp / Borst',
      ZONE_HEAD: 'Hoofd & Nek',
      ZONE_LEFT_ARM: 'Linkerarm',
      ZONE_RIGHT_ARM: 'Rechterarm',
      ZONE_LEFT_LEG: 'Linkerbeen',
      ZONE_RIGHT_LEG: 'Rechterbeen',
    },
    apply: 'Toepassen',
    delete: 'Verwijderen',
    deleteAll: 'Wis Alle Tatoeages',
    opacity: 'Dekking',
  },
};

const urlParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
const isClothingOnly = urlParams?.get('shop') === 'clothing';

export const defaultMockConfig: CustomizationConfig = {
  ped: !isClothingOnly,
  headBlend: !isClothingOnly,
  faceFeatures: !isClothingOnly,
  headOverlays: !isClothingOnly,
  components: true,
  props: true,
  tattoos: !isClothingOnly,
  enableExit: true,
  hasTracker: false,
  automaticFade: false,
  componentConfig: {
    masks: true,
    upperBody: true,
    lowerBody: true,
    bags: true,
    shoes: true,
    scarfAndChains: true,
    shirts: true,
    bodyArmor: true,
    decals: true,
    jackets: true,
  },
  propConfig: {
    hats: true,
    glasses: true,
    ear: true,
    watches: true,
    bracelets: true,
  },
};

if (!import.meta.env.PROD) {
  mock('get_theme_configuration', () => ({
    currentTheme: 'default',
    themes: [
      {
        id: 'default',
        borderRadius: '12px',
        fontColor: '255, 255, 255',
        fontColorHover: '255, 255, 255',
        fontColorSelected: '255, 255, 255',
        fontFamily: 'Plus Jakarta Sans',
        primaryBackground: '14, 18, 27',
        primaryBackgroundSelected: '56, 189, 248',
        secondaryBackground: '14, 18, 27',
      },
    ],
  }));

  mock('appearance_get_locales', () => defaultMockLocales);

  mock('appearance_get_settings', () => ({
    appearanceSettings: {
      ...SETTINGS_INITIAL_STATE,
      eyeColor: { min: 0, max: 24 },
      hair: {
        ...SETTINGS_INITIAL_STATE.hair,
        color: {
          items: [
            [28, 28, 28],
            [54, 45, 39],
            [90, 70, 56],
            [133, 108, 88],
            [160, 132, 105],
            [185, 160, 129],
            [139, 117, 98],
            [168, 145, 121],
            [186, 166, 142],
            [198, 178, 153],
            [214, 196, 173],
            [223, 212, 197],
            [180, 152, 122],
            [146, 116, 86],
            [174, 129, 93],
            [189, 142, 101],
            [150, 85, 50],
            [130, 48, 26],
            [153, 50, 32],
            [127, 49, 51],
            [164, 48, 62],
            [171, 74, 91],
            [238, 55, 80],
            [238, 110, 61],
            [227, 142, 38],
            [56, 189, 248],
            [99, 102, 241],
            [168, 85, 247],
          ],
        },
      },
      tattoos: {
        items: {
          ZONE_TORSO: [
            {
              name: 'tattoo_tribal_chest',
              label: 'Tribal Eagle Chest',
              hashMale: 'mp_airraces_tat_000_M',
              hashFemale: 'mp_airraces_tat_000_F',
              zone: 'ZONE_TORSO',
              collection: 'mpairraces_overlays',
              opacity: 0.8,
            },
            {
              name: 'tattoo_snake_ribs',
              label: 'Cobra Ribs',
              hashMale: 'mp_airraces_tat_001_M',
              hashFemale: 'mp_airraces_tat_001_F',
              zone: 'ZONE_TORSO',
              collection: 'mpairraces_overlays',
              opacity: 0.9,
            },
          ],
          ZONE_HEAD: [],
          ZONE_LEFT_ARM: [],
          ZONE_RIGHT_ARM: [],
          ZONE_LEFT_LEG: [],
          ZONE_RIGHT_LEG: [],
        },
        opacity: {
          min: 0,
          max: 1,
          factor: 0.1,
        },
      },
    },
  }));

  mock('appearance_get_data', () => ({
    config: defaultMockConfig,
    appearanceData: { ...APPEARANCE_INITIAL_STATE, model: 'mp_m_freemode_01' },
  }));

  mock('appearance_change_model', () => ({
    appearanceSettings: SETTINGS_INITIAL_STATE,
    appearanceData: { ...APPEARANCE_INITIAL_STATE, model: 'mp_m_freemode_01' },
  }));

  mock('appearance_change_component', () => ({
    component_id: 11,
    drawable: { min: 0, max: 255 },
    texture: { min: 0, max: 255 },
    blacklist: { drawables: [], textures: [] },
  }));

  mock('appearance_change_prop', () => ({
    prop_id: 0,
    drawable: { min: -1, max: 255 },
    texture: { min: 0, max: 255 },
    blacklist: { drawables: [], textures: [] },
  }));
}
