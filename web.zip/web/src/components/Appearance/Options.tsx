import { ReactElement, ReactNode } from 'react';
import styled, { css } from 'styled-components';
import {
  FaSmile,
  FaMale,
  FaShoePrints,
  FaRedo,
  FaUndo,
  FaSave,
  FaTimes,
  FaTshirt,
  FaHatCowboy,
  FaSocks,
} from 'react-icons/fa';
import { FiRotateCw, FiCheck, FiX } from 'react-icons/fi';

import { CameraState, ClothesState, RotateState } from './interfaces';

interface OptionsProps {
  camera: CameraState;
  rotate: RotateState;
  clothes: ClothesState;
  handleSetClothes: (key: keyof ClothesState) => void;
  handleSetCamera: (key: keyof CameraState) => void;
  handleTurnAround: () => void;
  handleRotateLeft: () => void;
  handleRotateRight: () => void;
  handleSave: () => void;
  handleExit: () => void;
  enableExit: boolean;
}

const DockContainer = styled.div`
  margin: 24px 0 24px 14px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  z-index: 20;
  pointer-events: auto;
  animation: fadeInDock 0.4s cubic-bezier(0.16, 1, 0.3, 1);

  @keyframes fadeInDock {
    from {
      opacity: 0;
      transform: translateX(-15px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
`;

const CapsuleGroup = styled.div`
  background: rgba(11, 15, 25, 0.88);
  backdrop-filter: blur(24px) saturate(160%);
  -webkit-backdrop-filter: blur(24px) saturate(160%);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  padding: 5px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  box-shadow: 
    0 12px 28px rgba(0, 0, 0, 0.5),
    0 0 0 1px rgba(255, 255, 255, 0.04),
    inset 0 1px 0 rgba(255, 255, 255, 0.12);
`;

const CapsuleTitle = styled.div`
  font-size: 9px;
  font-weight: 700;
  letter-spacing: 0.6px;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.4);
  text-align: center;
  padding: 2px 0;
`;

const Tooltip = styled.div`
  position: absolute;
  left: calc(100% + 10px);
  top: 50%;
  transform: translateY(-50%);
  background: rgba(10, 14, 22, 0.96);
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: #ffffff;
  font-size: 11px;
  font-weight: 600;
  padding: 5px 9px;
  border-radius: 6px;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6);
  transition: opacity 0.15s ease, transform 0.15s ease;
  z-index: 100;
  display: flex;
  align-items: center;
  gap: 6px;

  kbd {
    padding: 1px 4px;
    border-radius: 4px;
    background: rgba(255, 255, 255, 0.15);
    font-size: 9px;
    font-family: 'JetBrains Mono', monospace;
    color: #38bdf8;
  }

  &::before {
    content: '';
    position: absolute;
    right: 100%;
    top: 50%;
    transform: translateY(-50%);
    border: 5px solid transparent;
    border-right-color: rgba(10, 14, 22, 0.96);
  }
`;

const IconButton = styled.button<{ active?: boolean; variant?: 'primary' | 'danger' | 'default' }>`
  height: 40px;
  width: 40px;
  border-radius: 8px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.7);
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.05);
  transition: background-color 0.12s ease, border-color 0.12s ease, color 0.12s ease;
  flex-shrink: 0;

  &:hover {
    color: #ffffff;
    background: rgba(255, 255, 255, 0.10);
    border-color: rgba(255, 255, 255, 0.15);

    ${Tooltip} {
      opacity: 1;
      transform: translateY(-50%) translateX(2px);
    }
  }

  &:active {
    opacity: 0.9;
  }

  ${({ active }) =>
    active &&
    css`
      color: #ffffff;
      background: #0284c7;
      border-color: rgba(255, 255, 255, 0.25);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2);

      &:hover {
        background: #0369a1;
        border-color: rgba(255, 255, 255, 0.35);
      }
    `}

  ${({ variant }) => {
    if (variant === 'primary') {
      return css`
        background: #059669;
        color: #ffffff;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2);

        &:hover {
          background: #047857;
          border-color: rgba(255, 255, 255, 0.3);
          color: #ffffff;
        }
      `;
    }
    if (variant === 'danger') {
      return css`
        background: rgba(239, 68, 68, 0.15);
        color: #f87171;
        border: 1px solid rgba(239, 68, 68, 0.25);

        &:hover {
          background: rgba(239, 68, 68, 0.28);
          color: #ffffff;
          border-color: rgba(239, 68, 68, 0.4);
        }
      `;
    }
  }}
`;

const KeyHint = styled.span`
  position: absolute;
  bottom: 2px;
  right: 3px;
  font-size: 8px;
  font-weight: 700;
  font-family: 'JetBrains Mono', monospace;
  color: rgba(255, 255, 255, 0.5);
  pointer-events: none;
`;

const Options: React.FC<OptionsProps> = ({
  camera,
  rotate,
  clothes,
  handleSetClothes,
  handleSetCamera,
  handleTurnAround,
  handleRotateLeft,
  handleRotateRight,
  handleExit,
  handleSave,
  enableExit,
}) => {
  return (
    <DockContainer>
    
      <CapsuleGroup>
        <CapsuleTitle>Camera</CapsuleTitle>
        <IconButton
          type="button"
          active={camera.head}
          onClick={() => handleSetCamera('head')}
          title="Camera: Gezicht"
        >
          <FaSmile size={18} />
          <Tooltip>Camera: Gezicht</Tooltip>
        </IconButton>
        <IconButton
          type="button"
          active={camera.body}
          onClick={() => handleSetCamera('body')}
          title="Camera: Lichaam"
        >
          <FaMale size={18} />
          <Tooltip>Camera: Lichaam</Tooltip>
        </IconButton>
        <IconButton
          type="button"
          active={camera.bottom}
          onClick={() => handleSetCamera('bottom')}
          title="Camera: Schoenen"
        >
          <FaShoePrints size={16} />
          <Tooltip>Camera: Schoenen</Tooltip>
        </IconButton>
      </CapsuleGroup>

    
      <CapsuleGroup>
        <CapsuleTitle>Draaien</CapsuleTitle>
        <IconButton
          type="button"
          active={rotate.left}
          onClick={handleRotateLeft}
          title="Draai Links [A]"
        >
          <FaRedo size={16} />
          <KeyHint>A</KeyHint>
          <Tooltip>
            Draai Links <kbd>A</kbd>
          </Tooltip>
        </IconButton>
        <IconButton type="button" onClick={handleTurnAround} title="Omdraaien 180°">
          <FiRotateCw size={17} />
          <Tooltip>Omdraaien 180°</Tooltip>
        </IconButton>
        <IconButton
          type="button"
          active={rotate.right}
          onClick={handleRotateRight}
          title="Draai Rechts [D]"
        >
          <FaUndo size={16} />
          <KeyHint>D</KeyHint>
          <Tooltip>
            Draai Rechts <kbd>D</kbd>
          </Tooltip>
        </IconButton>
      </CapsuleGroup>

      <CapsuleGroup>
        <CapsuleTitle>Kleding</CapsuleTitle>
        <IconButton
          type="button"
          active={clothes.head}
          onClick={() => handleSetClothes('head')}
          title="Toggle Hoofddeksel"
        >
          <FaHatCowboy size={17} />
          <Tooltip>Hoofddeksel {clothes.head ? 'Aan' : 'Uit'}</Tooltip>
        </IconButton>
        <IconButton
          type="button"
          active={clothes.body}
          onClick={() => handleSetClothes('body')}
          title="Toggle Bovenkleding"
        >
          <FaTshirt size={16} />
          <Tooltip>Bovenkleding {clothes.body ? 'Aan' : 'Uit'}</Tooltip>
        </IconButton>
        <IconButton
          type="button"
          active={clothes.bottom}
          onClick={() => handleSetClothes('bottom')}
          title="Toggle Onderkleding"
        >
          <FaSocks size={16} />
          <Tooltip>Onderkleding {clothes.bottom ? 'Aan' : 'Uit'}</Tooltip>
        </IconButton>
      </CapsuleGroup>

   
      <CapsuleGroup>
        <IconButton
          type="button"
          variant="primary"
          onClick={handleSave}
          title="Wijzigingen Opslaan"
        >
          <FiCheck size={20} strokeWidth={3} />
          <Tooltip>Wijzigingen Opslaan</Tooltip>
        </IconButton>
        {enableExit && (
          <IconButton
            type="button"
            variant="danger"
            onClick={handleExit}
            title="Menu Verlaten"
          >
            <FiX size={20} strokeWidth={2.5} />
            <Tooltip>Menu Verlaten</Tooltip>
          </IconButton>
        )}
      </CapsuleGroup>
    </DockContainer>
  );
};

export default Options;
