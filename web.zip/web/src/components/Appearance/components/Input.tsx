import { useCallback, useRef, useState, useEffect } from 'react';
import styled from 'styled-components';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';

interface InputProps {
  title?: string;
  min?: number;
  max?: number;
  blacklisted?: number[];
  defaultValue: number;
  clientValue: number;
  onChange: (value: number) => void;
}

const Container = styled.div`
  min-width: 0;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  gap: 6px;
`;

const LabelRow = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.65);

  .title-text {
    font-weight: 500;
    color: rgba(255, 255, 255, 0.75);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .value-badge {
    display: flex;
    align-items: center;
    gap: 4px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: #38bdf8;
    background: rgba(2, 132, 199, 0.12);
    padding: 2px 6px;
    border-radius: 6px;
    border: 1px solid rgba(56, 189, 248, 0.18);

    .max-text {
      color: rgba(255, 255, 255, 0.35);
    }

    .saved-text {
      color: #10b981;
      margin-left: 2px;
    }
  }
`;

const ControlWrapper = styled.div`
  min-width: 0;
  height: 36px;
  display: flex;
  align-items: center;
  background: rgba(10, 14, 21, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 8px;
  padding: 2px;
  position: relative;
  overflow: hidden;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;

  &:focus-within {
    border-color: rgba(56, 189, 248, 0.5);
    box-shadow: 0 0 0 1px rgba(56, 189, 248, 0.25);
  }
`;

const StepButton = styled.button`
  height: 100%;
  width: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.7);
  background: rgba(255, 255, 255, 0.04);
  border-radius: 6px;
  transition: background-color 0.12s ease, color 0.12s ease;
  flex-shrink: 0;

  &:hover {
    color: #ffffff;
    background: rgba(2, 132, 199, 0.22);
  }

  &:active {
    background: rgba(2, 132, 199, 0.35);
    color: #ffffff;
  }
`;

const NumberInput = styled.input`
  min-width: 0;
  height: 100%;
  flex: 1;
  text-align: center;
  font-family: 'JetBrains Mono', monospace;
  font-size: 13px;
  font-weight: 600;
  color: #ffffff;
  background: transparent;
  border: none;
  outline: none;
  padding: 0 4px;

  &::-webkit-outer-spin-button,
  &::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;

const MiniProgressBar = styled.div<{ percent: number }>`
  position: absolute;
  bottom: 0;
  left: 0;
  height: 2px;
  width: ${({ percent }) => `${percent}%`};
  background: #0284c7;
  transition: width 0.15s ease-out;
  pointer-events: none;
  opacity: 0.9;
`;

const Input: React.FC<InputProps> = ({
  title,
  min = 0,
  max = 255,
  blacklisted = [],
  defaultValue,
  clientValue,
  onChange,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const holdIntervalRef = useRef<any>(null);
  const holdTimeoutRef = useRef<any>(null);

  const handleContainerClick = useCallback(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [inputRef]);

  const isBlacklisted = function (_value: number, bl: number[]) {
    for (let i = 0; i < bl.length; i++) {
      if (bl[i] === _value) {
        return true;
      }
    }
    return false;
  };

  const normalize = function (_value: number) {
    if (_value < min) {
      _value = max;
    } else if (_value > max) {
      _value = min;
    }
    return _value;
  };

  const checkBlacklisted = function (_value: number, bl: number[], factor: number) {
    if (factor === 0) {
      if (!isBlacklisted(_value, bl)) {
        return normalize(_value);
      }
      factor = _value > defaultValue ? 1 : -1;
    }

    do {
      _value = normalize(_value + factor);
    } while (isBlacklisted(_value, bl));
    return _value;
  };

  const getSafeValue = useCallback(
    (_value: number, factor: number) => {
      return checkBlacklisted(_value, blacklisted, factor);
    },
    [min, max, blacklisted, defaultValue],
  );

  const handleChange = useCallback(
    (_value: any, factor: number) => {
      let parsedValue;

      if (!_value && _value !== 0) return;
      if (Number.isNaN(_value)) return;

      if (typeof _value === 'string') {
        parsedValue = parseInt(_value, 10);
      } else {
        parsedValue = _value;
      }

      const safeValue = getSafeValue(parsedValue, factor);
      onChange(safeValue);
    },
    [getSafeValue, onChange],
  );

  const currentValRef = useRef(defaultValue);
  useEffect(() => {
    currentValRef.current = defaultValue;
  }, [defaultValue]);

  // Hold-to-step support for smooth rapid scrolling
  const startHold = (factor: number) => {
    handleChange(currentValRef.current, factor);
    holdTimeoutRef.current = setTimeout(() => {
      holdIntervalRef.current = setInterval(() => {
        handleChange(currentValRef.current, factor);
      }, 70);
    }, 280);
  };

  const stopHold = () => {
    if (holdTimeoutRef.current) clearTimeout(holdTimeoutRef.current);
    if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
  };

  useEffect(() => {
    return () => stopHold();
  }, []);

  // Calculate percentage for visual fill
  const rangeSpan = Math.max(1, max - min);
  const percent = Math.min(100, Math.max(0, ((defaultValue - min) / rangeSpan) * 100));

  return (
    <Container onClick={handleContainerClick}>
      {title && (
        <LabelRow>
          <span className="title-text">{title}</span>
          <span className="value-badge">
            <span>{defaultValue}</span>
            <span className="max-text">/ {max}</span>
            {clientValue !== undefined && clientValue !== defaultValue && (
              <span className="saved-text" title="Opgeslagen waarde">
                • {clientValue}
              </span>
            )}
          </span>
        </LabelRow>
      )}
      <ControlWrapper>
        <StepButton
          type="button"
          onClick={() => handleChange(defaultValue, -1)}
          onMouseDown={() => startHold(-1)}
          onMouseUp={stopHold}
          onMouseLeave={stopHold}
          title="Vorige"
        >
          <FiChevronLeft size={16} strokeWidth={2.5} />
        </StepButton>
        <NumberInput
          type="number"
          ref={inputRef}
          value={defaultValue}
          onChange={e => handleChange(e.target.value, 0)}
        />
        <StepButton
          type="button"
          onClick={() => handleChange(defaultValue, 1)}
          onMouseDown={() => startHold(1)}
          onMouseUp={stopHold}
          onMouseLeave={stopHold}
          title="Volgende"
        >
          <FiChevronRight size={16} strokeWidth={2.5} />
        </StepButton>
      </ControlWrapper>
    </Container>
  );
};

export default Input;
