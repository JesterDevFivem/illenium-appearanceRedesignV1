import { ReactNode } from 'react';
import styled, { css } from 'styled-components';

interface ButtonProps {
  children: string | ReactNode;
  margin?: string;
  width?: string;
  variant?: 'primary' | 'secondary' | 'danger';
  onClick: () => void;
}

const CustomButton = styled.button<{ margin?: string; width?: string; variant?: string }>`
  padding: 8px 16px;
  margin: ${({ margin }) => margin || '0px'};
  width: ${({ width }) => width || 'auto'};
  min-height: 36px;
  border-radius: 8px;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.2px;
  cursor: pointer;
  transition: background-color 0.12s ease, border-color 0.12s ease, color 0.12s ease;

  ${({ variant }) => {
    switch (variant) {
      case 'danger':
        return css`
          background: rgba(239, 68, 68, 0.15);
          color: #f87171;
          border: 1px solid rgba(239, 68, 68, 0.25);

          &:hover {
            background: rgba(239, 68, 68, 0.25);
            border-color: rgba(239, 68, 68, 0.4);
            color: #ffffff;
          }
        `;
      case 'primary':
        return css`
          background: #0284c7;
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.15);
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2);

          &:hover {
            background: #0369a1;
            border-color: rgba(255, 255, 255, 0.25);
          }
        `;
      default:
        return css`
          background: rgba(255, 255, 255, 0.05);
          color: rgba(255, 255, 255, 0.8);
          border: 1px solid rgba(255, 255, 255, 0.07);

          &:hover {
            background: rgba(255, 255, 255, 0.09);
            border-color: rgba(255, 255, 255, 0.12);
            color: #ffffff;
          }
        `;
    }
  }}

  &:active {
    opacity: 0.9;
  }
`;

const Button = ({ children, onClick, margin, width, variant }: ButtonProps) => {
  return (
    <CustomButton type="button" onClick={onClick} margin={margin} width={width} variant={variant}>
      {children}
    </CustomButton>
  );
};

export default Button;
