import { useRef } from 'react';
import styled from 'styled-components';
import Select from 'react-select';

interface SelectInputProps {
  title: string;
  items: string[];
  defaultValue: string;
  clientValue: string;
  onChange: (value: string) => void;
}

const Container = styled.div`
  min-width: 0;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  gap: 6px;
`;

const LabelRow = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.65);

  .title-text {
    font-weight: 500;
    color: rgba(255, 255, 255, 0.75);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .value-badge {
    display: flex;
    align-items: center;
    gap: 4px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: #38bdf8;
    background: rgba(2, 132, 199, 0.12);
    padding: 2px 6px;
    border-radius: 6px;
    border: 1px solid rgba(56, 189, 248, 0.18);

    .saved-text {
      color: #10b981;
      margin-left: 2px;
    }
  }
`;

const customStyles: any = {
  control: (styles: any, { isFocused }: any) => ({
    ...styles,
    background: 'rgba(10, 14, 21, 0.75)',
    minHeight: '36px',
    height: '36px',
    fontSize: '12px',
    fontWeight: '500',
    color: '#ffffff',
    border: isFocused ? '1px solid rgba(56, 189, 248, 0.5)' : '1px solid rgba(255, 255, 255, 0.08)',
    borderRadius: '8px',
    outline: 'none',
    boxShadow: isFocused ? '0 0 0 1px rgba(56, 189, 248, 0.25)' : 'none',
    cursor: 'pointer',
    transition: 'border-color 0.15s ease',
    '&:hover': {
      borderColor: 'rgba(255, 255, 255, 0.16)',
    },
  }),
  valueContainer: (styles: any) => ({
    ...styles,
    padding: '0 10px',
  }),
  placeholder: (styles: any) => ({
    ...styles,
    fontSize: '12px',
    color: 'rgba(255, 255, 255, 0.35)',
  }),
  input: (styles: any) => ({
    ...styles,
    fontSize: '12px',
    color: '#ffffff',
    margin: 0,
    padding: 0,
  }),
  singleValue: (styles: any) => ({
    ...styles,
    fontSize: '12px',
    fontWeight: '500',
    color: '#ffffff',
  }),
  indicatorSeparator: () => ({
    display: 'none',
  }),
  dropdownIndicator: (styles: any, { isFocused }: any) => ({
    ...styles,
    color: isFocused ? '#38bdf8' : 'rgba(255, 255, 255, 0.4)',
    padding: '0 8px',
    transition: 'color 0.2s',
    '&:hover': {
      color: '#ffffff',
    },
  }),
  menuPortal: (styles: any) => ({
    ...styles,
    zIndex: 9999,
  }),
  menu: (styles: any) => ({
    ...styles,
    background: 'rgba(14, 18, 27, 0.96)',
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '12px',
    boxShadow: '0 16px 36px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(255, 255, 255, 0.05)',
    padding: '6px',
    overflow: 'hidden',
    zIndex: 9999,
  }),
  menuList: (styles: any) => ({
    ...styles,
    padding: 0,
    maxHeight: '180px',
    '&::-webkit-scrollbar': {
      width: '4px',
    },
    '&::-webkit-scrollbar-track': {
      background: 'transparent',
    },
    '&::-webkit-scrollbar-thumb': {
      borderRadius: '999px',
      background: 'rgba(255, 255, 255, 0.2)',
    },
  }),
  option: (styles: any, { isFocused, isSelected }: any) => ({
    ...styles,
    borderRadius: '6px',
    fontSize: '12px',
    fontWeight: isSelected ? '600' : '500',
    margin: '2px 0',
    padding: '8px 10px',
    cursor: 'pointer',
    color: isSelected ? '#ffffff' : isFocused ? '#ffffff' : 'rgba(255, 255, 255, 0.75)',
    background: isSelected
      ? '#0284c7'
      : isFocused
      ? 'rgba(255, 255, 255, 0.08)'
      : 'transparent',
    transition: 'background-color 0.12s ease, color 0.12s ease',
  }),
};

const SelectInput = ({ title, items, defaultValue, clientValue, onChange }: SelectInputProps) => {
  const selectRef = useRef<any>(null);

  const handleChange = (event: any, { action }: any): void => {
    if (action === 'select-option') {
      onChange(event.value);
    }
  };

  const onMenuOpen = () => {
    setTimeout(() => {
      const selectedEl = document.getElementsByClassName(`Select${title}__option--is-selected`)[0];
      if (selectedEl) {
        selectedEl.scrollIntoView({ behavior: 'auto', block: 'start', inline: 'nearest' });
      }
    }, 100);
  };

  return (
    <Container>
      <LabelRow>
        <span className="title-text">{title}</span>
        {clientValue && (
          <span className="value-badge">
            <span>{defaultValue}</span>
            {clientValue !== defaultValue && (
              <span className="saved-text" title="Opgeslagen waarde">
                • {clientValue}
              </span>
            )}
          </span>
        )}
      </LabelRow>
      <Select
        ref={selectRef}
        styles={customStyles}
        options={items.map(item => ({ value: item, label: item }))}
        value={{ value: defaultValue, label: defaultValue }}
        onChange={handleChange}
        onMenuOpen={onMenuOpen}
        className={`Select${title}`}
        classNamePrefix={`Select${title}`}
        menuPortalTarget={document.body}
      />
    </Container>
  );
};

export default SelectInput;
