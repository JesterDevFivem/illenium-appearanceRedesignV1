import styled from 'styled-components';
import { ReactNode } from 'react';

interface ItemProps {
  title?: string;
  children?: ReactNode;
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
  padding: 10px 12px;
  border-radius: 10px;
  background: rgba(14, 18, 27, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.05);
  transition: background-color 0.15s ease, border-color 0.15s ease;

  &:hover {
    background: rgba(18, 23, 34, 0.75);
    border-color: rgba(255, 255, 255, 0.09);
  }
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 8px;

  span {
    color: rgba(255, 255, 255, 0.90);
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 0.2px;
    text-transform: capitalize;
  }
`;

const Inputs = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

const Item: React.FC<ItemProps> = ({ children, title }) => {
  return (
    <Container>
      {title && (
        <Header>
          <span>{title}</span>
        </Header>
      )}
      <Inputs>{children}</Inputs>
    </Container>
  );
};

export default Item;
