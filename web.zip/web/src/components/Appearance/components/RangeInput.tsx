import { useCallback, useRef } from 'react';
import styled from 'styled-components';

interface RangeInputProps {
  title?: string;
  min: number;
  max: number;
  factor?: number;
  defaultValue?: number;
  clientValue?: number;
  onChange: (value: number) => void;
}

const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 6px;
`;

const LabelRow = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.65);

  .title-text {
    font-weight: 500;
    color: rgba(255, 255, 255, 0.75);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .value-badge {
    display: flex;
    align-items: center;
    gap: 4px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: #38bdf8;
    background: rgba(2, 132, 199, 0.12);
    padding: 2px 6px;
    border-radius: 6px;
    border: 1px solid rgba(56, 189, 248, 0.18);

    .saved-text {
      color: #10b981;
      margin-left: 2px;
    }
  }
`;

const SliderContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  position: relative;
  height: 32px;
  padding: 0 4px;

  .bound-label {
    font-size: 10px;
    font-family: 'JetBrains Mono', monospace;
    color: rgba(255, 255, 255, 0.35);
    min-width: 16px;
    text-align: center;
  }
`;

const SliderWrapper = styled.div<{ percent: number }>`
  position: relative;
  flex: 1;
  display: flex;
  align-items: center;
  height: 100%;


  &::before {
    content: '';
    position: absolute;
    left: 0;
    width: ${({ percent }) => `${percent}%`};
    height: 4px;
    border-radius: 999px;
    background: #0284c7;
    pointer-events: none;
    z-index: 1;
  }

  input[type='range'] {
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 4px;
    background: rgba(10, 14, 21, 0.75);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 999px;
    outline: none;
    position: relative;
    cursor: pointer;
    margin: 0;

    &::-webkit-slider-thumb {
      -webkit-appearance: none;
      appearance: none;
      width: 15px;
      height: 15px;
      border-radius: 50%;
      background: #ffffff;
      border: 2px solid #0284c7;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.5);
      cursor: grab;
      position: relative;
      z-index: 2;
      transition: border-color 0.12s ease, box-shadow 0.12s ease;

      &:hover {
        border-color: #38bdf8;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.7);
      }

      &:active {
        cursor: grabbing;
        border-color: #38bdf8;
      }
    }

    &::-moz-range-thumb {
      width: 15px;
      height: 15px;
      border-radius: 50%;
      background: #ffffff;
      border: 2px solid #0284c7;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.5);
      cursor: pointer;
      z-index: 2;
    }
  }
`;

const RangeInput: React.FC<RangeInputProps> = ({
  min,
  max,
  factor = 1,
  title,
  defaultValue = 1,
  clientValue,
  onChange,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleContainerClick = useCallback(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [inputRef]);

  const handleChange = useCallback(
    (e: { target: { value: string } }) => {
      const parsedValue = parseFloat(e.target.value);
      onChange(parsedValue);
    },
    [onChange],
  );

  const rangeSpan = Math.max(0.0001, max - min);
  const percent = Math.min(100, Math.max(0, ((defaultValue - min) / rangeSpan) * 100));

  // Format display value: if integer display as is, otherwise round to 2 decimals
  const formattedVal = Number.isInteger(defaultValue)
    ? defaultValue
    : parseFloat(defaultValue.toFixed(2));

  return (
    <Container onClick={handleContainerClick}>
      {title && (
        <LabelRow>
          <span className="title-text">{title}</span>
          <span className="value-badge">
            <span>{formattedVal}</span>
            {clientValue !== undefined && clientValue !== defaultValue && (
              <span className="saved-text" title="Opgeslagen waarde">
                • {typeof clientValue === 'number' ? (Number.isInteger(clientValue) ? clientValue : clientValue.toFixed(2)) : clientValue}
              </span>
            )}
          </span>
        </LabelRow>
      )}
      <SliderContainer>
        <span className="bound-label">{min}</span>
        <SliderWrapper percent={percent}>
          <input
            type="range"
            ref={inputRef}
            value={defaultValue}
            min={min}
            max={max}
            step={factor}
            onChange={handleChange}
          />
        </SliderWrapper>
        <span className="bound-label">{max}</span>
      </SliderContainer>
    </Container>
  );
};

export default RangeInput;
