import { useCallback, useEffect, useRef, useState } from 'react';
import styled from 'styled-components';
import Select from 'react-select';
import { useNuiState } from '../../../hooks/nuiState';
import Button from './Button';
import { Tattoo, TattoosSettings } from '../interfaces';
import RangeInput from './RangeInput';
import { FiCheck, FiTrash2 } from 'react-icons/fi';

interface SelectTattooProps {
  items: Tattoo[];
  tattoosApplied: Tattoo[] | null;
  handleApplyTattoo: (value: Tattoo, opacity: number) => void;
  handlePreviewTattoo: (value: Tattoo, opacity: number) => void;
  handleDeleteTattoo: (value: Tattoo) => void;
  settings: TattoosSettings;
}

const Container = styled.div`
  min-width: 0;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  gap: 10px;

  > section {
    width: 100%;
    display: flex;
    justify-content: flex-end;
    gap: 8px;
  }
`;

const customStyles: any = {
  control: (styles: any, { isFocused }: any) => ({
    ...styles,
    background: 'rgba(10, 14, 21, 0.75)',
    minHeight: '36px',
    height: '36px',
    fontSize: '12px',
    fontWeight: '500',
    color: '#ffffff',
    border: isFocused ? '1px solid rgba(56, 189, 248, 0.5)' : '1px solid rgba(255, 255, 255, 0.08)',
    borderRadius: '10px',
    outline: 'none',
    boxShadow: isFocused ? '0 0 12px rgba(56, 189, 248, 0.2)' : 'none',
    cursor: 'pointer',
    transition: 'all 0.2s',
  }),
  valueContainer: (styles: any) => ({
    ...styles,
    padding: '0 10px',
  }),
  placeholder: (styles: any) => ({
    ...styles,
    fontSize: '12px',
    color: 'rgba(255, 255, 255, 0.35)',
  }),
  input: (styles: any) => ({
    ...styles,
    fontSize: '12px',
    color: '#ffffff',
    margin: 0,
    padding: 0,
  }),
  singleValue: (styles: any) => ({
    ...styles,
    fontSize: '12px',
    fontWeight: '500',
    color: '#ffffff',
  }),
  indicatorSeparator: () => ({
    display: 'none',
  }),
  dropdownIndicator: (styles: any, { isFocused }: any) => ({
    ...styles,
    color: isFocused ? '#38bdf8' : 'rgba(255, 255, 255, 0.4)',
    padding: '0 8px',
  }),
  menuPortal: (styles: any) => ({
    ...styles,
    zIndex: 9999,
  }),
  menu: (styles: any) => ({
    ...styles,
    background: 'rgba(14, 18, 27, 0.96)',
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '8px',
    boxShadow: '0 12px 28px rgba(0, 0, 0, 0.65)',
    padding: '6px',
    overflow: 'hidden',
    zIndex: 9999,
  }),
  menuList: (styles: any) => ({
    ...styles,
    padding: 0,
    maxHeight: '180px',
    '&::-webkit-scrollbar': {
      width: '4px',
    },
    '&::-webkit-scrollbar-thumb': {
      borderRadius: '999px',
      background: 'rgba(255, 255, 255, 0.2)',
    },
  }),
  option: (styles: any, { isFocused, isSelected }: any) => ({
    ...styles,
    borderRadius: '8px',
    fontSize: '12px',
    fontWeight: isSelected ? '600' : '500',
    margin: '2px 0',
    padding: '8px 10px',
    cursor: 'pointer',
    color: isSelected ? '#ffffff' : isFocused ? '#ffffff' : 'rgba(255, 255, 255, 0.75)',
    background: isSelected
      ? '#0284c7'
      : isFocused
      ? 'rgba(255, 255, 255, 0.08)'
      : 'transparent',
    transition: 'background-color 0.12s ease, color 0.12s ease',
  }),
};

const SelectTattoo = ({
  items,
  tattoosApplied,
  handleApplyTattoo,
  handlePreviewTattoo,
  handleDeleteTattoo,
  settings,
}: SelectTattooProps) => {
  const defaultOpacity = 0.1;
  const selectRef = useRef<any>(null);
  const [currentTattoo, setCurrentTattoo] = useState<Tattoo>(items[0]);
  const [opacity, setOpacity] = useState<number>(defaultOpacity);
  const { label } = currentTattoo || {};
  const { locales } = useNuiState();

  const clientOpacity = useCallback(() => {
    if (!tattoosApplied || !currentTattoo) return defaultOpacity;
    const { name } = currentTattoo;
    for (let i = 0; i < tattoosApplied.length; i++) {
      const { name: nameApplied } = tattoosApplied[i];
      if (nameApplied === name) {
        return tattoosApplied[i].opacity ?? defaultOpacity;
      }
    }
    return defaultOpacity;
  }, [currentTattoo, tattoosApplied])();

  useEffect(() => {
    setOpacity(clientOpacity);
  }, [clientOpacity]);

  const handleChange = (event: any, { action }: any): void => {
    if (action === 'select-option') {
      handlePreviewTattoo(event.value, opacity);
      setCurrentTattoo(event.value);
    }
  };

  const handleChangeOpacity = useCallback(
    (value: number) => {
      setOpacity(value);
      if (currentTattoo) {
        handlePreviewTattoo(currentTattoo, value);
      }
    },
    [currentTattoo, handlePreviewTattoo],
  );

  const onMenuOpen = () => {
    setTimeout(() => {
      if (items.length > 0) {
        const selectedEl = document.getElementsByClassName(
          `TattooDropdown${items[0].zone}__option--is-selected`,
        )[0];
        if (selectedEl) {
          selectedEl.scrollIntoView({ behavior: 'auto', block: 'start', inline: 'nearest' });
        }
      }
    }, 100);
  };

  const isTattooApplied = useCallback(() => {
    if (!tattoosApplied || !currentTattoo) return false;
    const { name } = currentTattoo;
    for (let i = 0; i < tattoosApplied.length; i++) {
      const { name: nameApplied } = tattoosApplied[i];
      if (nameApplied === name) return true;
    }
    return false;
  }, [tattoosApplied, currentTattoo])();

  if (!locales || !currentTattoo) {
    return null;
  }

  return (
    <Container>
      <Select
        ref={selectRef}
        styles={customStyles}
        options={items.map(item => ({ value: item, label: item.label }))}
        value={{ value: currentTattoo, label }}
        onChange={handleChange}
        onMenuOpen={onMenuOpen}
        className={`TattooDropdown${items[0]?.zone || 'zone'}`}
        classNamePrefix={`TattooDropdown${items[0]?.zone || 'zone'}`}
        menuPortalTarget={document.body}
        menuShouldScrollIntoView={true}
      />
      <RangeInput
        title={locales.tattoos.opacity}
        min={settings.opacity.min}
        max={settings.opacity.max}
        factor={settings.opacity.factor}
        defaultValue={opacity}
        clientValue={clientOpacity}
        onChange={value => handleChangeOpacity(value)}
      />
      <section>
        {isTattooApplied ? (
          <Button variant="danger" onClick={() => handleDeleteTattoo(currentTattoo)}>
            <FiTrash2 size={14} />
            {locales.tattoos.delete}
          </Button>
        ) : (
          <Button variant="primary" onClick={() => handleApplyTattoo(currentTattoo, opacity)}>
            <FiCheck size={14} />
            {locales.tattoos.apply}
          </Button>
        )}
      </section>
    </Container>
  );
};

export default SelectTattoo;
