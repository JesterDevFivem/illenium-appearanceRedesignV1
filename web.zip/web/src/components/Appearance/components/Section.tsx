import { useState, useEffect, useRef, ReactNode } from 'react';
import styled, { css } from 'styled-components';
import { FiChevronDown, FiUser, FiSmile, FiEye, FiScissors, FiLayers, FiWatch } from 'react-icons/fi';
import { GiClothes, GiTribalMask } from 'react-icons/gi';
import { useSpring, animated } from 'react-spring';

interface SectionProps {
  title: string;
  deps?: any[];
  children?: ReactNode;
  defaultOpen?: boolean;
}

interface HeaderProps {
  active: boolean;
}

const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  user-select: none;
  border-radius: 12px;
  background: rgba(17, 24, 39, 0.65);
  border: 1px solid rgba(255, 255, 255, 0.07);
  transition: background-color 0.15s ease, border-color 0.15s ease;
  overflow: hidden;
  flex-shrink: 0;

  &:hover {
    border-color: rgba(255, 255, 255, 0.12);
    background: rgba(22, 31, 50, 0.75);
  }
`;

const Header = styled.div<HeaderProps>`
  width: 100%;
  height: 48px;
  min-height: 48px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 14px;
  cursor: pointer;
  position: relative;
  flex-shrink: 0;
  transition: background-color 0.15s ease, border-color 0.15s ease;

  ${({ active }) =>
    active
      ? css`
          background: rgba(2, 132, 199, 0.08);
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        `
      : css`
          &:hover {
            background: rgba(255, 255, 255, 0.03);
          }
        `}
`;

const TitleWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  flex: 1;
`;

const IconPill = styled.div<{ active: boolean }>`
  width: 28px;
  height: 28px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  flex-shrink: 0;
  transition: background-color 0.15s ease, color 0.15s ease, border-color 0.15s ease;

  ${({ active }) =>
    active
      ? css`
          background: rgba(2, 132, 199, 0.18);
          color: #38bdf8;
          border: 1px solid rgba(56, 189, 248, 0.3);
        `
      : css`
          background: rgba(255, 255, 255, 0.04);
          color: rgba(255, 255, 255, 0.5);
          border: 1px solid rgba(255, 255, 255, 0.04);
        `}
`;

const Title = styled.span<{ active: boolean }>`
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.3px;
  text-transform: capitalize;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: ${({ active }) => (active ? '#ffffff' : 'rgba(255, 255, 255, 0.82)')};
  transition: color 0.2s;
`;

const ChevronWrapper = styled.div<{ active: boolean }>`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: ${({ active }) => (active ? '#38bdf8' : 'rgba(255, 255, 255, 0.4)')};
  transform: ${({ active }) => (active ? 'rotate(180deg)' : 'rotate(0deg)')};
  transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), color 0.2s;
`;

const Items = styled.div`
  padding: 10px 12px 14px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

// Helper to choose appropriate category icon based on title string
const getSectionIcon = (title: string) => {
  const t = title.toLowerCase();
  if (t.includes('ped') || t.includes('model') || t.includes('personage')) return <FiUser />;
  if (t.includes('blend') || t.includes('erfelijkheid') || t.includes('heritage') || t.includes('face') || t.includes('gezicht')) return <FiSmile />;
  if (t.includes('feature') || t.includes('kenmerk') || t.includes('oog') || t.includes('eye')) return <FiEye />;
  if (t.includes('hair') || t.includes('haar') || t.includes('beard') || t.includes('baard') || t.includes('overlay')) return <FiScissors />;
  if (t.includes('prop') || t.includes('accessoire') || t.includes('bril') || t.includes('horloge')) return <FiWatch />;
  if (t.includes('tattoo') || t.includes('tatoeage')) return <GiTribalMask />;
  if (t.includes('component') || t.includes('kleding') || t.includes('clothes') || t.includes('outfit')) return <GiClothes />;
  return <FiLayers />;
};

const Section: React.FC<SectionProps> = ({ children, title, deps = [], defaultOpen = false }) => {
  const [active, setActive] = useState(defaultOpen);
  const [height, setHeight] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  const props = useSpring({
    height: active ? height : 0,
    opacity: active ? 1 : 0,
    config: { tension: 320, friction: 28 },
  });

  useEffect(() => {
    if (ref.current) {
      setHeight(ref.current.offsetHeight);
    }
  }, [ref, active]);

  useEffect(() => {
    if (ref.current) {
      setHeight(ref.current.offsetHeight);
    }
  }, [deps]);

  return (
    <Container>
      <Header active={active} onClick={() => setActive(state => !state)}>
        <TitleWrapper>
          <IconPill active={active}>{getSectionIcon(title)}</IconPill>
          <Title active={active}>{title}</Title>
        </TitleWrapper>
        <ChevronWrapper active={active}>
          <FiChevronDown size={18} />
        </ChevronWrapper>
      </Header>

      <animated.div style={{ ...props, overflow: 'hidden' }}>
        <Items ref={ref}>{children}</Items>
      </animated.div>
    </Container>
  );
};

export default Section;
