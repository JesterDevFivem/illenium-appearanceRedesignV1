import { useCallback } from 'react';
import styled, { css } from 'styled-components';

interface ColorInputProps {
  title?: string;
  colors?: number[][];
  defaultValue?: number;
  clientValue?: number;
  onChange: (value: number) => void;
}

interface ButtonProps {
  selected: boolean;
}

const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

const LabelRow = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.65);

  .left-side {
    display: flex;
    align-items: center;
    gap: 8px;

    .title-text {
      font-weight: 500;
      color: rgba(255, 255, 255, 0.75);
    }
  }

  .value-badge {
    display: flex;
    align-items: center;
    gap: 6px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: #38bdf8;
    background: rgba(2, 132, 199, 0.12);
    padding: 2px 6px;
    border-radius: 6px;
    border: 1px solid rgba(56, 189, 248, 0.18);

    .saved-text {
      color: #10b981;
      margin-left: 2px;
    }
  }
`;

const CurrentColorPreview = styled.div<{ colorRgb: string }>`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: ${({ colorRgb }) => colorRgb};
  border: 1.5px solid rgba(255, 255, 255, 0.6);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
`;

const SwatchGrid = styled.div`
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  max-height: 110px;
  overflow-y: auto;
  padding: 4px 2px;


  &::-webkit-scrollbar {
    width: 3px;
  }
  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 999px;
  }
`;

const SwatchButton = styled.button<ButtonProps>`
  height: 22px;
  width: 22px;
  border-radius: 6px;
  border: 1px solid rgba(0, 0, 0, 0.5);
  position: relative;
  transition: outline 0.12s ease, box-shadow 0.12s ease;
  flex-shrink: 0;

  &:hover {
    outline: 2px solid rgba(255, 255, 255, 0.5);
    outline-offset: 1px;
    z-index: 5;
  }

  ${({ selected }) =>
    selected &&
    css`
      outline: 2px solid #38bdf8;
      outline-offset: 1.5px;
      border-color: #ffffff;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
      z-index: 4;

      &::after {
        content: '';
        position: absolute;
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: #ffffff;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        box-shadow: 0 0 3px rgba(0, 0, 0, 0.8);
      }
    `}
`;

const ColorInput: React.FC<ColorInputProps> = ({
  title,
  colors = [],
  defaultValue = 0,
  clientValue,
  onChange,
}) => {
  const selectColor = useCallback(
    (color: number) => {
      onChange(color);
    },
    [onChange],
  );

  const activeColor = colors[defaultValue] || [255, 255, 255];
  const activeColorRgb = `rgb(${activeColor[0]}, ${activeColor[1]}, ${activeColor[2]})`;

  return (
    <Container>
      {title && (
        <LabelRow>
          <div className="left-side">
            <CurrentColorPreview colorRgb={activeColorRgb} />
            <span className="title-text">{title}</span>
          </div>
          <span className="value-badge">
            <span>#{defaultValue}</span>
            {clientValue !== undefined && clientValue !== defaultValue && (
              <span className="saved-text" title="Opgeslagen kleur">
                • #{clientValue}
              </span>
            )}
          </span>
        </LabelRow>
      )}
      <SwatchGrid>
        {colors.map((color, index) => (
          <SwatchButton
            key={index}
            type="button"
            style={{ backgroundColor: `rgb(${color[0]}, ${color[1]}, ${color[2]})` }}
            selected={defaultValue === index}
            onClick={() => selectColor(index)}
            title={`Kleur ${index}`}
          />
        ))}
      </SwatchGrid>
    </Container>
  );
};

export default ColorInput;
