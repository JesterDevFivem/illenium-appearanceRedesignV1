import styled from 'styled-components';

export const Wrapper = styled.div`
  height: 100vh;
  width: 100vw;
  position: relative;
  display: flex;
  align-items: stretch;
  justify-content: flex-start;
  overflow: hidden;
  background: radial-gradient(
    circle at 15% 50%,
    rgba(10, 14, 22, 0.75) 0%,
    rgba(10, 14, 22, 0.35) 45%,
    transparent 75%
  );
  pointer-events: none;

  > * {
    pointer-events: auto;
  }
`;

export const Container = styled.div`
  height: calc(100vh - 48px);
  width: 420px;
  max-width: calc(100vw - 48px);
  margin: 24px 0 24px 28px;
  position: relative;
  display: flex;
  flex-direction: column;
  z-index: 10;

  background: rgba(${props => props.theme?.secondaryBackground || '11, 15, 25'}, 0.88);
  backdrop-filter: blur(24px) saturate(160%);
  -webkit-backdrop-filter: blur(24px) saturate(160%);
  border: 1px solid rgba(255, 255, 255, 0.09);
  border-radius: 16px;
  box-shadow: 
    0 20px 48px -10px rgba(0, 0, 0, 0.75),
    0 0 0 1px rgba(255, 255, 255, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.15);

  overflow: hidden;
  animation: slideInMenu 0.3s cubic-bezier(0.16, 1, 0.3, 1);

  @keyframes slideInMenu {
    from {
      opacity: 0;
      transform: translateX(-24px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
`;

export const ScrollArea = styled.div`
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 16px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;


  &::-webkit-scrollbar {
    width: 4px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 999px;
  }

  &::-webkit-scrollbar-thumb:hover {
    background: rgba(56, 189, 248, 0.4);
  }
`;

export const FlexWrapper = styled.div`
  width: 100%;
  display: flex;
  gap: 8px;

  > div {
    flex: 1;
    min-width: 0;
  }
`;
