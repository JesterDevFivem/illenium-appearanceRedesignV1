import { useState, useEffect, useCallback, useMemo } from 'react';
import { useTransition as useTransitionAnimation, animated } from 'react-spring';
import { useNuiState } from '../../hooks/nuiState';
import Nui from '../../Nui';
import mock from '../../mock';

import {
  CustomizationConfig,
  PedAppearance,
  AppearanceSettings,
  PedHeadBlend,
  PedFaceFeatures,
  PedHeadOverlays,
  PedHeadOverlayValue,
  PedHair,
  CameraState,
  ClothesState,
  Tattoo,
  TattoosSettings,
} from './interfaces';

import {
  APPEARANCE_INITIAL_STATE,
  SETTINGS_INITIAL_STATE,
  CAMERA_INITIAL_STATE,
  ROTATE_INITIAL_STATE,
  CLOTHES_INITIAL_STATE,
} from './settings';

import Ped from './Ped';
import HeadBlend from './HeadBlend';
import FaceFeatures from './FaceFeatures';
import HeadOverlays from './HeadOverlays';
import Components from './Components';
import Props from './Props';
import Options from './Options';
import Modal from '../Modal';
import Tattoos from './Tattoos';

import {
  Wrapper,
  Container,
  ScrollArea,
} from './styles';

// Enhanced dev mocks for local testing outside FiveM
if (!import.meta.env.PROD) {
  const defaultMockLocales = {
    modal: {
      save: {
        title: 'Uiterlijk Opslaan',
        description: 'Weet je zeker dat je jouw huidige uiterlijk en kleding wilt opslaan?',
      },
      exit: {
        title: 'Menu Verlaten',
        description: 'Weet je zeker dat je wilt afsluiten? Niet-opgeslagen wijzigingen gaan verloren.',
      },
      accept: 'Opslaan',
      decline: 'Annuleren',
    },
    ped: {
      title: 'Personage Model',
      model: 'Model',
    },
    headBlend: {
      title: 'Erfelijkheid & Vorm',
      shape: {
        title: 'Vader & Moeder Vorm',
        firstOption: 'Vader Vorm',
        secondOption: 'Moeder Vorm',
        mix: 'Vorm Mix',
      },
      skin: {
        title: 'Vader & Moeder Huid',
        firstOption: 'Vader Huid',
        secondOption: 'Moeder Huid',
        mix: 'Huid Mix',
      },
      race: {
        title: 'Derde Erfelijkheid',
        shape: 'Derde Vorm',
        skin: 'Derde Huid',
        mix: 'Derde Mix',
      },
    },
    faceFeatures: {
      title: 'Gelaatstrekken',
      nose: {
        title: 'Neus',
        width: 'Breedte',
        height: 'Hoogte',
        size: 'Grootte',
        boneHeight: 'Bot Hoogte',
        boneTwist: 'Bot Verdraaiing',
        peakHeight: 'Punt Hoogte',
      },
      eyebrows: {
        title: 'Wenkbrauwen',
        height: 'Hoogte',
        depth: 'Diepte',
      },
      cheeks: {
        title: 'Wangen',
        boneHeight: 'Jukbeen Hoogte',
        boneWidth: 'Jukbeen Breedte',
        width: 'Wang Breedte',
      },
      eyesAndMouth: {
        title: 'Ogen & Mond',
        eyesOpening: 'Oog Opening',
        lipsThickness: 'Lip Dikte',
      },
      jaw: {
        title: 'Kaak',
        width: 'Kaak Breedte',
        size: 'Kaak Lengte',
      },
      chin: {
        title: 'Kin',
        lowering: 'Kin Hoogte',
        length: 'Kin Lengte',
        size: 'Kin Grootte',
        hole: 'Kin Kuiltje',
      },
      neck: {
        title: 'Nek',
        thickness: 'Nek Dikte',
      },
    },
    headOverlays: {
      title: 'Haar & Verzorging',
      hair: {
        title: 'Haar',
        style: 'Kapsel',
        color: 'Kleur',
        highlight: 'Highlight',
        fade: 'Fade / Overloop',
        texture: 'Textuur',
      },
      opacity: 'Dekking',
      style: 'Stijl',
      color: 'Kleur',
      secondColor: 'Tweede Kleur',
      blemishes: 'Huidoneffenheden',
      beard: 'Baard',
      eyebrows: 'Wenkbrauwen',
      ageing: 'Veroudering',
      makeUp: 'Make-up',
      blush: 'Blush',
      complexion: 'Teint',
      sunDamage: 'Zonschade',
      lipstick: 'Lippenstift',
      moleAndFreckles: 'Sproeten & Vlekken',
      chestHair: 'Borsthaar',
      bodyBlemishes: 'Lichaamsoneffenheden',
      eyeColor: 'Oogkleur',
    },
    components: {
      title: 'Kleding & Outfits',
      drawable: 'Kledingstuk',
      texture: 'Variatie / Textuur',
      mask: 'Maskers',
      upperBody: 'Bovenlichaam & Armen',
      lowerBody: 'Broeken',
      bags: 'Tassen & Uitrusting',
      shoes: 'Schoenen',
      scarfAndChains: 'Kettingen & Sjaals',
      shirt: 'T-Shirts & Onderkleding',
      bodyArmor: 'Kogelvrije Vesten',
      decals: 'Badges & Emblemen',
      jackets: 'Jassen & Bovenkleding',
      head: 'Hoofd',
    },
    props: {
      title: 'Accessoires',
      drawable: 'Accessoire',
      texture: 'Variatie / Textuur',
      hats: 'Hoeden & Helmen',
      glasses: 'Brillen',
      ear: 'Oorbellen',
      watches: 'Horloges',
      bracelets: 'Armbanden',
    },
    tattoos: {
      title: 'Tatoeages',
      items: {
        ZONE_TORSO: 'Romp / Borst',
        ZONE_HEAD: 'Hoofd & Nek',
        ZONE_LEFT_ARM: 'Linkerarm',
        ZONE_RIGHT_ARM: 'Rechterarm',
        ZONE_LEFT_LEG: 'Linkerbeen',
        ZONE_RIGHT_LEG: 'Rechterbeen',
      },
      apply: 'Toepassen',
      delete: 'Verwijderen',
      deleteAll: 'Wis Alle Tatoeages',
      opacity: 'Dekking',
    },
  };

  const urlParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
  const isClothingOnly = urlParams?.get('shop') === 'clothing';

  const defaultMockConfig: CustomizationConfig = {
    ped: !isClothingOnly,
    headBlend: !isClothingOnly,
    faceFeatures: !isClothingOnly,
    headOverlays: !isClothingOnly,
    components: true,
    props: true,
    tattoos: !isClothingOnly,
    enableExit: true,
    hasTracker: false,
    automaticFade: false,
    componentConfig: {
      masks: true,
      upperBody: true,
      lowerBody: true,
      bags: true,
      shoes: true,
      scarfAndChains: true,
      shirts: true,
      bodyArmor: true,
      decals: true,
      jackets: true,
    },
    propConfig: {
      hats: true,
      glasses: true,
      ear: true,
      watches: true,
      bracelets: true,
    },
  };

  mock('appearance_get_locales', () => defaultMockLocales);

  mock('get_theme_configuration', () => ({
    currentTheme: 'default',
    themes: [
      {
        id: 'default',
        borderRadius: '12px',
        fontColor: '255, 255, 255',
        fontColorHover: '255, 255, 255',
        fontColorSelected: '255, 255, 255',
        fontFamily: 'Plus Jakarta Sans',
        primaryBackground: '14, 18, 27',
        primaryBackgroundSelected: '56, 189, 248',
        secondaryBackground: '14, 18, 27',
      },
    ],
  }));

  mock('appearance_get_settings', () => ({
    appearanceSettings: {
      ...SETTINGS_INITIAL_STATE,
      eyeColor: { min: 0, max: 24 },
      hair: {
        ...SETTINGS_INITIAL_STATE.hair,
        color: {
          items: [
            [28, 28, 28],
            [54, 45, 39],
            [90, 70, 56],
            [133, 108, 88],
            [160, 132, 105],
            [185, 160, 129],
            [139, 117, 98],
            [168, 145, 121],
            [186, 166, 142],
            [198, 178, 153],
            [214, 196, 173],
            [223, 212, 197],
            [180, 152, 122],
            [146, 116, 86],
            [174, 129, 93],
            [189, 142, 101],
            [150, 85, 50],
            [130, 48, 26],
            [153, 50, 32],
            [127, 49, 51],
            [164, 48, 62],
            [171, 74, 91],
            [238, 55, 80],
            [238, 110, 61],
            [227, 142, 38],
            [56, 189, 248],
            [99, 102, 241],
            [168, 85, 247],
          ],
        },
      },
    },
  }));

  mock('appearance_get_data', () => ({
    config: defaultMockConfig,
    appearanceData: { ...APPEARANCE_INITIAL_STATE, model: 'mp_m_freemode_01' },
  }));

  mock('appearance_change_model', () => ({
    appearanceSettings: SETTINGS_INITIAL_STATE,
    appearanceData: { ...APPEARANCE_INITIAL_STATE, model: 'mp_m_freemode_01' },
  }));

  mock('appearance_change_component', () => ({
    component_id: 11,
    drawable: { min: 0, max: 255 },
    texture: { min: 0, max: 255 },
    blacklist: { drawables: [], textures: [] },
  }));

  mock('appearance_change_prop', () => ({
    prop_id: 0,
    drawable: { min: -1, max: 255 },
    texture: { min: 0, max: 255 },
    blacklist: { drawables: [], textures: [] },
  }));
}

const Appearance = () => {
  const [config, setConfig] = useState<CustomizationConfig>();

  const [data, setData] = useState<PedAppearance>();
  const [storedData, setStoredData] = useState<PedAppearance>();
  const [appearanceSettings, setAppearanceSettings] = useState<AppearanceSettings>();

  const [camera, setCamera] = useState(CAMERA_INITIAL_STATE);
  const [rotate, setRotate] = useState(ROTATE_INITIAL_STATE);
  const [clothes, setClothes] = useState(CLOTHES_INITIAL_STATE);

  const [saveModal, setSaveModal] = useState(false);
  const [exitModal, setExitModal] = useState(false);

  const { display, setDisplay, locales, setLocales } = useNuiState();

  const wrapperTransition = useTransitionAnimation(display.appearance, null, {
    from: { transform: 'translateX(-40px)', opacity: 0 },
    enter: { transform: 'translateX(0)', opacity: 1 },
    leave: { transform: 'translateX(-40px)', opacity: 0 },
  });

  const saveModalTransition = useTransitionAnimation(saveModal, null, {
    from: { opacity: 0 },
    enter: { opacity: 1 },
    leave: { opacity: 0 },
  });

  const exitModalTransition = useTransitionAnimation(exitModal, null, {
    from: { opacity: 0 },
    enter: { opacity: 1 },
    leave: { opacity: 0 },
  });

  const handleTurnAround = useCallback(() => {
    Nui.post('appearance_turn_around');
  }, []);

  const handleSetClothes = useCallback(
    (key: keyof ClothesState) => {
      setClothes({ ...clothes, [key]: !clothes[key] });
      if (!clothes[key]) {
        Nui.post('appearance_remove_clothes', key);
      } else {
        Nui.post('appearance_wear_clothes', { data, key });
      }
    },
    [data, clothes, setClothes],
  );

  const handleSetCamera = useCallback(
    (key: keyof CameraState) => {
      setCamera({ ...CAMERA_INITIAL_STATE, [key]: !camera[key] });
      setRotate(ROTATE_INITIAL_STATE);

      if (!camera[key]) {
        Nui.post('appearance_set_camera', key);
      } else {
        Nui.post('appearance_set_camera', 'default');
      }
    },
    [camera, setCamera, setRotate],
  );

  const handleRotateLeft = useCallback(() => {
    setRotate({ left: !rotate.left, right: false });

    if (!rotate.left) {
      Nui.post('appearance_rotate_camera', 'left');
    } else {
      Nui.post('appearance_set_camera', 'current');
    }
  }, [setRotate, rotate]);

  const handleRotateRight = useCallback(() => {
    setRotate({ left: false, right: !rotate.right });

    if (!rotate.right) {
      Nui.post('appearance_rotate_camera', 'right');
    } else {
      Nui.post('appearance_set_camera', 'current');
    }
  }, [setRotate, rotate]);

  const handleSaveModal = useCallback(() => {
    setSaveModal(true);
  }, [setSaveModal]);

  const handleExitModal = useCallback(() => {
    setExitModal(true);
  }, [setExitModal]);

  const handleSave = useCallback(
    async (accept: boolean) => {
      if (accept) {
        await Nui.post('appearance_save', data);
        setSaveModal(false);
      } else {
        setSaveModal(false);
      }
    },
    [setSaveModal, data],
  );

  const handleExit = useCallback(
    async (accept: boolean) => {
      if (accept) {
        await Nui.post('appearance_exit');
        setExitModal(false);
      } else {
        setExitModal(false);
      }
    },
    [setExitModal],
  );

  const handleModelChange = useCallback(
    async (value: string) => {
      const { appearanceSettings: _appearanceSettings, appearanceData } = await Nui.post(
        'appearance_change_model',
        value,
      );

      setAppearanceSettings(_appearanceSettings);
      setData(appearanceData);
    },
    [setData, setAppearanceSettings],
  );

  const handleHeadBlendChange = useCallback(
    (key: keyof PedHeadBlend, value: number) => {
      if (!data) return;

      const updatedHeadBlend = { ...data.headBlend, [key]: value };
      const updatedData = { ...data, headBlend: updatedHeadBlend };

      setData(updatedData);
      Nui.post('appearance_change_head_blend', updatedHeadBlend);
    },
    [data, setData],
  );

  const handleFaceFeatureChange = useCallback(
    (key: keyof PedFaceFeatures, value: number) => {
      if (!data) return;

      const updatedFaceFeatures = { ...data.faceFeatures, [key]: value };
      const updatedData = { ...data, faceFeatures: updatedFaceFeatures };

      setData(updatedData);
      Nui.post('appearance_change_face_feature', updatedFaceFeatures);
    },
    [data, setData],
  );

  const handleHairChange = useCallback(
    async (key: keyof PedHair, value: number) => {
      if (!data || !appearanceSettings) return;

      const updatedHair = { ...data.hair, [key]: value };
      const updatedData = { ...data, hair: updatedHair };

      setData(updatedData);

      const updatedHairSettings = await Nui.post('appearance_change_hair', updatedHair);
      const updatedSettings = { ...appearanceSettings, hair: updatedHairSettings };

      setAppearanceSettings(updatedSettings);
    },
    [data, setData, appearanceSettings, setAppearanceSettings],
  );

  const handleChangeFade = useCallback(
    async (value: number) => {
      if (!data || !appearanceSettings) return;
      const { tattoos } = data;
      const updatedTattoos = { ...tattoos };
      const tattoo = appearanceSettings.tattoos.items['ZONE_HAIR']?.[value];
      if (tattoo) {
        if (!updatedTattoos[tattoo.zone]) updatedTattoos[tattoo.zone] = [];
        updatedTattoos[tattoo.zone] = [tattoo];
        await Nui.post('appearance_apply_tattoo', updatedTattoos);
        setData({ ...data, tattoos: updatedTattoos });
      }
    },
    [appearanceSettings, data, setData],
  );

  const handleHeadOverlayChange = useCallback(
    (key: keyof PedHeadOverlays, option: keyof PedHeadOverlayValue, value: number) => {
      if (!data) return;

      const updatedValue = { ...data.headOverlays[key], [option]: value };
      const updatedData = { ...data, headOverlays: { ...data.headOverlays, [key]: updatedValue } };

      setData(updatedData);
      Nui.post('appearance_change_head_overlay', { ...data.headOverlays, [key]: updatedValue });
    },
    [data, setData],
  );

  const handleEyeColorChange = useCallback(
    (value: number) => {
      if (!data) return;

      const updatedData = { ...data, eyeColor: value };
      setData(updatedData);
      Nui.post('appearance_change_eye_color', value);
    },
    [data, setData],
  );

  const handleComponentDrawableChange = useCallback(
    async (component_id: number, drawable: number) => {
      if (!data || !appearanceSettings) return;

      const component = data.components.find(c => c.component_id === component_id);
      if (!component) return;

      const updatedComponent = { ...component, drawable, texture: 0 };
      const filteredComponents = data.components.filter(c => c.component_id !== component_id);
      const updatedComponents = [...filteredComponents, updatedComponent];
      const updatedData = { ...data, components: updatedComponents };

      setData(updatedData);

      const updatedComponentSettings = await Nui.post('appearance_change_component', updatedComponent);
      const filteredComponentsSettings = appearanceSettings.components.filter(c => c.component_id !== component_id);
      const updatedComponentsSettings = [...filteredComponentsSettings, updatedComponentSettings];
      const updatedSettings = { ...appearanceSettings, components: updatedComponentsSettings };

      setAppearanceSettings(updatedSettings);
    },
    [data, setData, appearanceSettings, setAppearanceSettings],
  );

  const handleComponentTextureChange = useCallback(
    async (component_id: number, texture: number) => {
      if (!data || !appearanceSettings) return;

      const component = data.components.find(c => c.component_id === component_id);
      if (!component) return;

      const updatedComponent = { ...component, texture };
      const filteredComponents = data.components.filter(c => c.component_id !== component_id);
      const updatedComponents = [...filteredComponents, updatedComponent];
      const updatedData = { ...data, components: updatedComponents };

      setData(updatedData);

      const updatedComponentSettings = await Nui.post('appearance_change_component', updatedComponent);
      const filteredComponentsSettings = appearanceSettings.components.filter(c => c.component_id !== component_id);
      const updatedComponentsSettings = [...filteredComponentsSettings, updatedComponentSettings];
      const updatedSettings = { ...appearanceSettings, components: updatedComponentsSettings };

      setAppearanceSettings(updatedSettings);
    },
    [data, setData, appearanceSettings, setAppearanceSettings],
  );

  const handlePropDrawableChange = useCallback(
    async (prop_id: number, drawable: number) => {
      if (!data || !appearanceSettings) return;

      const prop = data.props.find(p => p.prop_id === prop_id);
      if (!prop) return;

      const updatedProp = { ...prop, drawable, texture: 0 };
      const filteredProps = data.props.filter(p => p.prop_id !== prop_id);
      const updatedProps = [...filteredProps, updatedProp];
      const updatedData = { ...data, props: updatedProps };

      setData(updatedData);

      const updatedPropSettings = await Nui.post('appearance_change_prop', updatedProp);
      const filteredPropsSettings = appearanceSettings.props.filter(c => c.prop_id !== prop_id);
      const updatedPropsSettings = [...filteredPropsSettings, updatedPropSettings];
      const updatedSettings = { ...appearanceSettings, props: updatedPropsSettings };

      setAppearanceSettings(updatedSettings);
    },
    [data, setData, appearanceSettings, setAppearanceSettings],
  );

  const handlePropTextureChange = useCallback(
    async (prop_id: number, texture: number) => {
      if (!data || !appearanceSettings) return;

      const prop = data.props.find(p => p.prop_id === prop_id);
      if (!prop) return;

      const updatedProp = { ...prop, texture };
      const filteredProps = data.props.filter(p => p.prop_id !== prop_id);
      const updatedProps = [...filteredProps, updatedProp];
      const updatedData = { ...data, props: updatedProps };

      setData(updatedData);

      const updatedPropSettings = await Nui.post('appearance_change_prop', updatedProp);
      const filteredPropsSettings = appearanceSettings.props.filter(c => c.prop_id !== prop_id);
      const updatedPropsSettings = [...filteredPropsSettings, updatedPropSettings];
      const updatedSettings = { ...appearanceSettings, props: updatedPropsSettings };

      setAppearanceSettings(updatedSettings);
    },
    [data, setData, appearanceSettings, setAppearanceSettings],
  );

  const isPedFreemodeModel = useMemo(() => {
    if (!data) return;
    return data.model === 'mp_m_freemode_01' || data.model === 'mp_f_freemode_01';
  }, [data]);

  const isPedMale = useMemo(() => {
    if (!data) return;
    return data.model === 'mp_m_freemode_01';
  }, [data]);

  const filterTattoos = (tattooSettings: TattoosSettings) => {
    const copy = { ...tattooSettings, items: { ...tattooSettings.items } };
    for (const zone in copy.items) {
      copy.items[zone] = copy.items[zone].filter(tattoo => {
        if (isPedMale && tattoo.hashMale !== '') {
          return tattoo;
        } else if (!isPedMale && tattoo.hashFemale !== '') {
          return tattoo;
        }
        return false;
      });
    }
    return copy;
  };

  const handleApplyTattoo = useCallback(
    async (tattoo: Tattoo, opacity: number) => {
      if (!data) return;
      tattoo.opacity = opacity;
      const { tattoos } = data;
      const updatedTattoos = JSON.parse(JSON.stringify({ ...tattoos }));
      if (!updatedTattoos[tattoo.zone]) updatedTattoos[tattoo.zone] = [];
      updatedTattoos[tattoo.zone].push(tattoo);
      const applied = await Nui.post('appearance_apply_tattoo', { tattoo, updatedTattoos });
      if (applied) {
        setData({ ...data, tattoos: updatedTattoos });
      }
    },
    [data, setData],
  );

  const handlePreviewTattoo = useCallback(
    (tattoo: Tattoo, opacity: number) => {
      if (!data) return;
      tattoo.opacity = opacity;
      const { tattoos } = data;
      Nui.post('appearance_preview_tattoo', { data: tattoos, tattoo });
    },
    [data],
  );

  const handleDeleteTattoo = useCallback(
    async (tattoo: Tattoo) => {
      if (!data) return;
      const { tattoos } = data;
      const updatedTattoos = tattoos;
      updatedTattoos[tattoo.zone] = updatedTattoos[tattoo.zone].filter(
        tattooDelete => tattooDelete.name !== tattoo.name,
      );
      await Nui.post('appearance_delete_tattoo', updatedTattoos);
      setData({ ...data, tattoos: updatedTattoos });
    },
    [data, setData],
  );

  const handleClearTattoos = useCallback(async () => {
    if (!data) return;
    const { tattoos } = data;
    const updatedTattoos = { ...tattoos };
    for (const zone in updatedTattoos) {
      if (zone !== 'ZONE_HAIR') {
        updatedTattoos[zone] = [];
      }
    }
    await Nui.post('appearance_delete_tattoo', updatedTattoos);
    setData({ ...data, tattoos: updatedTattoos });
  }, [data, setData]);

  useEffect(() => {
    if (!locales) {
      Nui.post('appearance_get_locales').then(result => {
        if (result) setLocales(result);
      });
    }

    Nui.onEvent('appearance_display', (payload: any) => {
      setDisplay({ appearance: true, asynchronous: payload.asynchronous });
    });

    Nui.onEvent('appearance_hide', () => {
      setDisplay({ appearance: false, asynchronous: false });
      setData(APPEARANCE_INITIAL_STATE);
      setStoredData(APPEARANCE_INITIAL_STATE);
      setCamera(CAMERA_INITIAL_STATE);
      setRotate(ROTATE_INITIAL_STATE);
    });

    // In local development, auto-display the menu and add dev-mode class
    if (!import.meta.env.PROD) {
      document.body.classList.add('dev-mode');
      setDisplay({ appearance: true, asynchronous: false });
    }
  }, []);

  const fetchData = useCallback(async () => {
    const result = await Nui.post('appearance_get_data');
    if (result) {
      setConfig(result.config);
      setStoredData(result.appearanceData);
      setData(result.appearanceData);
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    if (appearanceSettings === undefined || appearanceSettings === SETTINGS_INITIAL_STATE) {
      const result = await Nui.post('appearance_get_settings');
      if (result) {
        setAppearanceSettings(result.appearanceSettings);
      }
    }
  }, [appearanceSettings]);

  useEffect(() => {
    if (display.appearance) {
      if (display.asynchronous) {
        (async () => {
          await fetchSettings();
          await fetchData();
        })();
      } else {
        fetchSettings().catch(console.error);
        fetchData().catch(console.error);
      }
    }
  }, [display.appearance]);

  if (!display.appearance || !config || !appearanceSettings || !data || !storedData || !locales) {
    return null;
  }

  return (
    <>
      {wrapperTransition.map(
        ({ item, key, props: style }) =>
          item && (
            <animated.div key={key} style={style}>
              <Wrapper>
                <Container>
                 
                  <ScrollArea>
                    {config.ped && (
                      <Ped
                        settings={appearanceSettings.ped}
                        storedData={storedData.model}
                        data={data.model}
                        handleModelChange={handleModelChange}
                      />
                    )}

                    {appearanceSettings && (
                      <>
                        {isPedFreemodeModel && config.headBlend && (
                          <HeadBlend
                            settings={appearanceSettings.headBlend}
                            storedData={storedData.headBlend}
                            data={data.headBlend}
                            handleHeadBlendChange={handleHeadBlendChange}
                          />
                        )}

                        {isPedFreemodeModel && config.faceFeatures && (
                          <FaceFeatures
                            settings={appearanceSettings.faceFeatures}
                            storedData={storedData.faceFeatures}
                            data={data.faceFeatures}
                            handleFaceFeatureChange={handleFaceFeatureChange}
                          />
                        )}

                        {config.headOverlays && (
                          <HeadOverlays
                            settings={{
                              hair: appearanceSettings.hair,
                              headOverlays: appearanceSettings.headOverlays,
                              eyeColor: appearanceSettings.eyeColor,
                              fade: appearanceSettings.tattoos?.items?.['ZONE_HAIR'] || [],
                            }}
                            storedData={{
                              hair: storedData.hair,
                              headOverlays: storedData.headOverlays,
                              eyeColor: storedData.eyeColor,
                              fade:
                                storedData.tattoos?.ZONE_HAIR?.length > 0
                                  ? storedData.tattoos.ZONE_HAIR[0]
                                  : null,
                            }}
                            data={{
                              hair: data.hair,
                              headOverlays: data.headOverlays,
                              eyeColor: data.eyeColor,
                              fade:
                                data.tattoos?.ZONE_HAIR?.length > 0
                                  ? data.tattoos.ZONE_HAIR[0]
                                  : null,
                            }}
                            isPedFreemodeModel={isPedFreemodeModel}
                            handleHairChange={handleHairChange}
                            handleHeadOverlayChange={handleHeadOverlayChange}
                            handleEyeColorChange={handleEyeColorChange}
                            handleChangeFade={handleChangeFade}
                            automaticFade={config.automaticFade}
                          />
                        )}
                      </>
                    )}

                    {config.components && (
                      <Components
                        settings={appearanceSettings.components}
                        data={data.components}
                        storedData={storedData.components}
                        handleComponentDrawableChange={handleComponentDrawableChange}
                        handleComponentTextureChange={handleComponentTextureChange}
                        componentConfig={config.componentConfig}
                        hasTracker={config.hasTracker}
                        isPedFreemodeModel={isPedFreemodeModel}
                      />
                    )}

                    {config.props && (
                      <Props
                        settings={appearanceSettings.props}
                        data={data.props}
                        storedData={storedData.props}
                        handlePropDrawableChange={handlePropDrawableChange}
                        handlePropTextureChange={handlePropTextureChange}
                        propConfig={config.propConfig}
                      />
                    )}

                    {isPedFreemodeModel && config.tattoos && (
                      <Tattoos
                        settings={filterTattoos(appearanceSettings.tattoos)}
                        data={data.tattoos}
                        storedData={storedData.tattoos}
                        handleApplyTattoo={handleApplyTattoo}
                        handlePreviewTattoo={handlePreviewTattoo}
                        handleDeleteTattoo={handleDeleteTattoo}
                        handleClearTattoos={handleClearTattoos}
                      />
                    )}
                  </ScrollArea>
                </Container>

               
                <Options
                  camera={camera}
                  rotate={rotate}
                  clothes={clothes}
                  handleSetClothes={handleSetClothes}
                  handleSetCamera={handleSetCamera}
                  handleTurnAround={handleTurnAround}
                  handleRotateLeft={handleRotateLeft}
                  handleRotateRight={handleRotateRight}
                  handleSave={handleSaveModal}
                  handleExit={handleExitModal}
                  enableExit={config.enableExit}
                />
              </Wrapper>
            </animated.div>
          ),
      )}

      {saveModalTransition.map(
        ({ item, key, props: style }) =>
          item && (
            <animated.div key={key} style={style}>
              <Modal
                title={locales.modal.save.title}
                description={locales.modal.save.description}
                accept={locales.modal.accept}
                decline={locales.modal.decline}
                handleAccept={() => handleSave(true)}
                handleDecline={() => handleSave(false)}
              />
            </animated.div>
          ),
      )}

      {exitModalTransition.map(
        ({ item, key, props: style }) =>
          item && (
            <animated.div key={key} style={style}>
              <Modal
                title={locales.modal.exit.title}
                description={locales.modal.exit.description}
                accept={locales.modal.accept}
                decline={locales.modal.decline}
                handleAccept={() => handleExit(true)}
                handleDecline={() => handleExit(false)}
              />
            </animated.div>
          ),
      )}
    </>
  );
};

export default Appearance;
