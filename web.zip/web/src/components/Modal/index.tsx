import { Wrapper, ModalCard, Buttons } from './styles';
import { FiCheck, FiX, FiSave, FiAlertCircle } from 'react-icons/fi';

interface ModalProps {
  title: string;
  description: string;
  accept: string;
  decline: string;
  handleAccept: () => Promise<void> | void;
  handleDecline: () => Promise<void> | void;
}

const Modal = ({ title, description, accept, decline, handleAccept, handleDecline }: ModalProps) => {
  const isSave =
    title.toLowerCase().includes('save') ||
    title.toLowerCase().includes('opslaan') ||
    description.toLowerCase().includes('save') ||
    description.toLowerCase().includes('opslaan');

  return (
    <Wrapper>
      <ModalCard>
        <div className="icon-badge">
          {isSave ? <FiSave size={26} /> : <FiAlertCircle size={26} />}
        </div>
        <h2>{title}</h2>
        <p>{description}</p>
        <Buttons>
          <button type="button" className="btn-decline" onClick={handleDecline}>
            <FiX size={16} />
            {decline}
          </button>
          <button type="button" className="btn-accept" onClick={handleAccept}>
            <FiCheck size={16} />
            {accept}
          </button>
        </Buttons>
      </ModalCard>
    </Wrapper>
  );
};

export default Modal;
