import styled from 'styled-components';

export const Wrapper = styled.div`
  width: 100vw;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  user-select: none;
  background: rgba(6, 9, 15, 0.72);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  z-index: 1000;
  animation: modalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);

  @keyframes modalFadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`;

export const ModalCard = styled.div`
  width: 420px;
  max-width: calc(100vw - 32px);
  background: rgba(16, 22, 34, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.10);
  border-radius: 16px;
  padding: 28px 24px 22px 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  box-shadow: 
    0 20px 50px rgba(0, 0, 0, 0.8),
    0 0 0 1px rgba(255, 255, 255, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.15);
  animation: cardPopIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);

  @keyframes cardPopIn {
    from {
      opacity: 0;
      transform: translateY(8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .icon-badge {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    background: rgba(2, 132, 199, 0.15);
    border: 1px solid rgba(56, 189, 248, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #38bdf8;
    margin-bottom: 18px;
  }

  h2 {
    font-size: 18px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: 0.2px;
    margin-bottom: 8px;
    text-transform: capitalize;
  }

  p {
    font-size: 13px;
    line-height: 1.5;
    color: rgba(255, 255, 255, 0.65);
    margin-bottom: 24px;
  }
`;

export const Buttons = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  width: 100%;

  button {
    flex: 1;
    height: 40px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.2px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: background-color 0.12s ease, border-color 0.12s ease, color 0.12s ease;

    &.btn-decline {
      background: rgba(255, 255, 255, 0.06);
      color: rgba(255, 255, 255, 0.8);
      border: 1px solid rgba(255, 255, 255, 0.08);

      &:hover {
        background: rgba(255, 255, 255, 0.10);
        color: #ffffff;
        border-color: rgba(255, 255, 255, 0.15);
      }
    }

    &.btn-accept {
      background: #0284c7;
      color: #ffffff;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2);

      &:hover {
        background: #0369a1;
        border-color: rgba(255, 255, 255, 0.25);
      }
    }

    &:active {
      opacity: 0.9;
    }
  }
`;
