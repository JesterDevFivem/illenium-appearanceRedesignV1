import { NuiStateProvider } from './hooks/nuiState';
import GlobalStyles from './styles/global';

import Appearance from './components/Appearance';
import { ThemeProvider } from 'styled-components';
import Nui from './Nui';
import { useCallback, useEffect, useState } from 'react';

const defaultTheme: any = {
  id: 'default',
  borderRadius: '12px',
  fontColor: '255, 255, 255',
  fontColorHover: '255, 255, 255',
  fontColorSelected: '255, 255, 255',
  fontFamily: 'Plus Jakarta Sans',
  primaryBackground: '14, 18, 27',
  primaryBackgroundSelected: '56, 189, 248',
  secondaryBackground: '14, 18, 27',
  scaleOnHover: true,
  sectionFontWeight: '600',
  smoothBackgroundTransition: true,
};

const App: React.FC = () => {
  const [currentTheme, setCurrentTheme] = useState(defaultTheme);

  const getCurrentTheme = (themeData: any) => {
    if (!themeData || !themeData.themes || !Array.isArray(themeData.themes)) {
      return defaultTheme;
    }
    for (let index = 0; index < themeData.themes.length; index++) {
      if (themeData.themes[index].id === themeData.currentTheme) {
        return themeData.themes[index];
      }
    }
    return defaultTheme;
  };

  const loadTheme = useCallback(async () => {
    try {
      const themeData = await Nui.post('get_theme_configuration');
      if (themeData) {
        setCurrentTheme(getCurrentTheme(themeData) || defaultTheme);
      }
    } catch (e) {
      console.warn('Using default theme', e);
    }
  }, []);

  useEffect(() => {
    loadTheme().catch(console.error);
  }, [loadTheme]);

  return (
    <NuiStateProvider>
      <ThemeProvider theme={currentTheme}>
        <Appearance />
        <GlobalStyles />
      </ThemeProvider>
    </NuiStateProvider>
  );
};

export default App;
